# @tiptap-pro/extension-convert-kit

## 0.9.0

### Minor Changes

- 09c7218: Header/footer content now renders identically while editing and on the page.

  Top-level block images in the header/footer static preview render at their natural size instead of being stretched to the full content width by the flex column layout, matching how the overlay editor renders the same content. Intentional centering via auto horizontal margins keeps working. Note that CSS scoped to your editor wrapper only reaches the in-page preview, not the editing overlay mounted on `document.body` — style header/footer images via image attributes or global CSS when both contexts must match.

  Tables now lay out in columns inside the header/footer editing overlay (and the measurement and offscreen sub-editors) instead of collapsing into a narrow stacked box. TableKit owns its grid table layout CSS — `display: contents` unwrapping plus per-row grid tracks — scoped to a `tiptap-pages-tablekit` marker class it adds to every editor that loads it, so the rules apply wherever the kit is used rather than only inside the main Pages editor's uniquely-scoped stylesheet. The injected stylesheet is also reference counted, so destroying one of several editors sharing it (for example a pooled header sub-editor on overlay reconfigure) no longer strips table styling from the editors still alive.

  ConvertKit newly exports the `injectSharedStyle` utility (and its `InjectSharedStyleOptions` type) so companion packages can reference count shared stylesheets across several editors instead of duplicating the lifecycle logic. Existing ConvertKit behavior is unchanged.

### Patch Changes

- e83429c: Tracked-change author and date helpers no longer throw when a suggestion carries a value that is not a string, such as a number or a `Date`. Those values now fall back to the anonymous author and the fallback date, so one malformed attribute can no longer fail a whole DOCX export or import.

## 0.8.0

### Minor Changes

- 2dc0088: Add tracked-changes revision identity helpers to the `ooxml-registry` subpath: author and date mapping between OOXML revisions and Tiptap suggestions, `userId` normalization, and a valid `w:date` fallback for export.

## 0.7.0

### Minor Changes

- 07b5835: Add internal-anchor support so in-document navigation round-trips with DOCX. A new bookmark node represents an anchor target, and links whose href is `#anchor` now export as Word internal hyperlinks that point at the matching bookmark instead of as external links.

### Patch Changes

- 9648903: Preserve the underline style when converting to and from DOCX. Double, dotted, dashed, wavy and the other Word underline patterns now round-trip instead of every underline becoming a plain single line. The underline mark gains an `underlineType` attribute, and the exporter emits the matching underline type.

## 0.6.0

### Minor Changes

- dad80a9: Add a dependency-free `@tiptap-pro/extension-convert-kit/ooxml-registry` subpath: a single source of truth for OOXML attribute mapping (unit conversions and attribute definitions) shared by DOCX import, export, and the editor schema. The existing paragraph, heading, and table cell attribute definitions now derive from it, with no change to their behavior.

### Patch Changes

- 8d98325: Add right and hanging indent support to DOCX conversion. Paragraphs and headings now carry a right indent (`w:ind` right) and hanging indents round-trip correctly, so legal-style numbered clauses and right-margin insets keep their shape through import and export.
- f75f1fa: Round-trip the DOCX keep-with-next (`w:keepNext`) and keep-lines-together (`w:keepLines`) pagination hints. Paragraphs and headings now carry `keepNext` and `keepLines` attributes that survive a conversion round-trip and export back to DOCX. They are layout hints with no visual effect in the editor, so they are stored on the node without affecting its HTML.
- 3d2b903: Add disclaimer banner to build
- 8e10677: Round-trip table borders (`w:tblBorders`) through DOCX conversion. A table's own six borders — outer edges plus the inside horizontal and vertical grid — are now preserved on the table itself, and cell border overrides carry across intact. Tables with no borders defined export as truly borderless instead of gaining a default border.
- e8fc491: Improve table fidelity when converting to DOCX. Cell and border colors written as a named color (`red`), `rgb()`/`rgba()`, or short hex (`#ff0`) now export correctly instead of failing, and fully transparent colors are dropped rather than turned opaque. Table rows with an "at least" height now show that height in the editor while still growing with their content. The Convert Kit table also honors the `renderWrapper` option again, so its static HTML output includes the table wrapper.
- bb0c18e: Fixed-width tables now export to DOCX with their column widths as the source of truth, so the table width, the column grid, and the individual cell widths always agree. When a table's declared width disagrees with its column widths, the columns win and the table width is the sum of the columns. Tables that are not cleanly sized fall back to an even split that is still internally consistent, and percentage-width tables are unchanged. The shared column-grid logic lives in the Convert Kit OOXML registry so import and export stay consistent.
- Updated dependencies [3d2b903]
  - @tiptap-pro/extension-pagebreak@0.3.4

## 0.5.2

### Patch Changes

- Updated dependencies [154e167]
  - @tiptap-pro/extension-pagebreak@0.3.3

## 0.5.1

### Patch Changes

- Updated dependencies [268e706]
  - @tiptap-pro/extension-pagebreak@0.3.2

## 0.5.0

### Minor Changes

- f0bc8a3: Carry ordered-list numbering through DOCX import. `ImportDocx` now surfaces the `numberingFormats` registry reconstructed by the convert service on the `onImport` context, and `setEditorContent` registers it with the `OrderedListNumbering` extension automatically so imported lists render their true markers (lettered, Roman, multilevel, custom start) right away. `OrderedListNumbering` gains a `registerNumberingFormats` command to add formats at runtime, and its storage exposes the merged `numberingFormats` for a faithful export back to DOCX.

## 0.4.0

### Minor Changes

- 47dfd9b: Improve `OrderedListNumbering` and multi-editor stylesheet handling:

  - Add a `toggleOrderedListWithFormat` command that starts an ordered list and applies a numbering format in one call — the one-call equivalent of `toggleOrderedList` followed by `setOrderedListNumberingFormat`, and the natural action for a "pick a format to start a numbered list" toolbar button. When the selection is already inside an ordered list, it toggles the list off, mirroring `toggleOrderedList`.
  - `orderedListNumbering` now accepts an options object: `defaultFormat` (the format new ordered lists start with) and `formats` (the same definitions passed to `ExportDocx.configure({ numberingFormats })`, from which the editor-preview CSS is generated and injected automatically). The injected stylesheet is keyed by its content, so editors configured with different formats each get their own correct stylesheet instead of the first one winning.
  - Enforce the outermost-only numbering invariant for content that bypasses `parseHTML` — JSON, collaborative sync, and programmatic edits — by clearing stale `numberingFormat` attributes from nested ordered lists.
  - Reference-count injected stylesheets (generic resets, contextual spacing, numbering preview) so the stylesheet shared by several editors is removed only when the last of them is destroyed, instead of when the first one unmounts.
  - `generateNumberingFormatCss` now emits `width: 100%` on each list item. Without it, the grid list item collapses to zero width in a shrink-to-fit context — e.g. when a paginating editor (`extension-pages`) splits a list across a page boundary — squeezing the item's text into a sliver in the page gutter.
  - `generateNumberingFormatCss` now maps locale `baseStyle` values (e.g. `hebrew1`, `japaneseCounting`, `koreanDigital`, `chineseCounting`, `thaiNumbers`, `ideographDigital`) onto the matching CSS Counter Styles Level 3 predefined styles, so those lists render their native glyph in the editor instead of falling back to decimal. Styles a browser doesn't support fall back to decimal on their own, and formats with no faithful CSS equivalent (e.g. `ordinal`, `cardinalText`, `chicago`) keep the decimal fallback.

## 0.3.0

### Minor Changes

- 6dd4766: Add editor-side ordered-list numbering support to ConvertKit, pairing with the `numberingFormats` option already available on `@tiptap-pro/extension-export-docx`.

  `@tiptap-pro/extension-convert-kit` now ships everything the editor side needs for custom DOCX numbering:

  - `OrderedListNumbering` — a Tiptap extension that adds a `numberingFormat` attribute to the outermost `<ol>`, a `setOrderedListNumberingFormat(id)` command, and an `editor.storage.orderedListNumbering.activeNumberingFormat` value that tracks the format at the current selection (handy for highlighting a toolbar). Registered automatically by `ConvertKit` (opt in via `orderedListNumbering: true`).
  - `generateNumberingFormatCss(formats, options?)` and `GenerateNumberingFormatCssOptions` — a typed, dependency-free CSS generator for in-editor preview of numbering formats. The preview honours `startAt` and marker font sizes given as docx measure strings, matching the exported `.docx`.
  - `NumberingFormatDefinition`, `NumberingLevelDefinition`, `NumberingBaseStyle`, `NumberingMarkerFont` — the types you write your registry against. Structurally compatible with `ExportDocx.configure({ numberingFormats })`, so one array drives both editor preview and DOCX export.

## 0.2.0

### Minor Changes

- eadb4c6: Bundle `UndoRedo` (from `@tiptap/extensions`) into `ConvertKit`. Undo/redo now works out of the box without an additional import, matching the parity of `StarterKit`-based setups. Disable with `ConvertKit.configure({ undoRedo: false })` if you provide your own history implementation.

## 0.1.1

### Patch Changes

- c189c62: Licensing

## 0.1.0

### Minor Changes

- 830279c: Initial release of ConvertKit — a single-import Tiptap extension bundle for rendering DOCX-imported content

  **Custom DOCX Extensions:**

  - Paragraph and Heading with spacing (`spacingBefore`, `spacingAfter`, `lineHeight`), `fontSize` (from DOCX paragraph mark for spacer paragraphs), indentation (`indent`, `hangingIndent`), and `contextualSpacing` attributes
  - Image with crop attributes (`cropTop`, `cropBottom`, `cropLeft`, `cropRight`)
  - Table with left indentation, `cellMinWidth: 1` for narrow DOCX spacer columns, and collapsed borders
  - TableRow with `height` and `heightRule` (exact/atLeast)
  - TableCell and TableHeader with `background`, `verticalAlign`, per-side border attributes (width, style, color), and a `.cell-content` wrapper div for height constraints
  - TableRow exposes height as a `--tr-height` CSS custom property for child cells

  **CSS Resets:**

  - Injects browser style resets on editor creation to normalize table rendering: `line-height: 1` on cells and rows, `vertical-align: top` on cells, `white-space: normal` on cell paragraphs, and zero default margins/padding — ensuring DOCX spacing values delivered as inline styles render accurately
  - Enforces exact row heights (`heightRule: "exact"`) by constraining the `.cell-content` wrapper div to the row's height with `overflow: hidden` — CSS `height`/`max-height` do not apply to `display: table-cell` elements, so the block-level wrapper is required

  **Table rendering fixes:**

  - Table extension accepts a new `width` attribute (parses/renders `width: Npx; max-width: 100%`) so DOCX-declared `w:tblW` values render accurately without overflowing the page container when the author drew the table wider than the content area
  - Table extension now clamps negative `indent` values to `0` at render time while preserving the raw value in attrs — negative `w:tblInd` values from DOCX (which rely on Word's paper gutter) no longer push tables past the page container's left edge; the original value is kept for export round-trip
  - TableRow extension `height` rendering now branches on `heightRule`: `exact` rows keep their hard-clipping behaviour via `height` + `--tr-height`; other rows (`atLeast` or unset) render as `min-height` so narrower columns can grow the row instead of clipping content

  **Bundled OSS Extensions:**

  - Includes 30+ standard Tiptap extensions (Document, Text, Bold, Italic, Underline, Strike, Code, Link, BulletList, OrderedList, ListItem, HardBreak, HorizontalRule, CodeBlock, TextStyleKit, TextAlign, Highlight, Superscript, Subscript, Dropcursor, Gapcursor, PageBreak) — all individually configurable or disableable via `ConvertKit.configure()`
