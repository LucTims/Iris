# @tiptap-pro/extension-pages-tablekit

## 0.2.13

### Patch Changes

- 50f44e4: Keep resized table columns within page bounds.

## 0.2.12

### Patch Changes

- 09c7218: Header/footer content now renders identically while editing and on the page.

  Top-level block images in the header/footer static preview render at their natural size instead of being stretched to the full content width by the flex column layout, matching how the overlay editor renders the same content. Intentional centering via auto horizontal margins keeps working. Note that CSS scoped to your editor wrapper only reaches the in-page preview, not the editing overlay mounted on `document.body` — style header/footer images via image attributes or global CSS when both contexts must match.

  Tables now lay out in columns inside the header/footer editing overlay (and the measurement and offscreen sub-editors) instead of collapsing into a narrow stacked box. TableKit owns its grid table layout CSS — `display: contents` unwrapping plus per-row grid tracks — scoped to a `tiptap-pages-tablekit` marker class it adds to every editor that loads it, so the rules apply wherever the kit is used rather than only inside the main Pages editor's uniquely-scoped stylesheet. The injected stylesheet is also reference counted, so destroying one of several editors sharing it (for example a pooled header sub-editor on overlay reconfigure) no longer strips table styling from the editors still alive.

  ConvertKit newly exports the `injectSharedStyle` utility (and its `InjectSharedStyleOptions` type) so companion packages can reference count shared stylesheets across several editors instead of duplicating the lifecycle logic. Existing ConvertKit behavior is unchanged.

- Updated dependencies [e83429c]
- Updated dependencies [09c7218]
  - @tiptap-pro/extension-convert-kit@0.9.0

## 0.2.11

### Patch Changes

- Updated dependencies [2dc0088]
  - @tiptap-pro/extension-convert-kit@0.8.0

## 0.2.10

### Patch Changes

- Updated dependencies [07b5835]
- Updated dependencies [9648903]
  - @tiptap-pro/extension-convert-kit@0.7.0

## 0.2.9

### Patch Changes

- 3d2b903: Add disclaimer banner to build
- Updated dependencies [8d98325]
- Updated dependencies [f75f1fa]
- Updated dependencies [3d2b903]
- Updated dependencies [dad80a9]
- Updated dependencies [8e10677]
- Updated dependencies [e8fc491]
- Updated dependencies [bb0c18e]
  - @tiptap-pro/extension-convert-kit@0.6.0

## 0.2.8

### Patch Changes

- @tiptap-pro/extension-convert-kit@0.5.2

## 0.2.7

### Patch Changes

- @tiptap-pro/extension-convert-kit@0.5.1

## 0.2.6

### Patch Changes

- Updated dependencies [f0bc8a3]
  - @tiptap-pro/extension-convert-kit@0.5.0

## 0.2.5

### Patch Changes

- Updated dependencies [47dfd9b]
  - @tiptap-pro/extension-convert-kit@0.4.0

## 0.2.4

### Patch Changes

- Updated dependencies [6dd4766]
  - @tiptap-pro/extension-convert-kit@0.3.0

## 0.2.3

### Patch Changes

- 99d887c: Pages' TableKit now correctly handles tables with custom widths set by table cell attributes
- Updated dependencies [eadb4c6]
  - @tiptap-pro/extension-convert-kit@0.2.0

## 0.2.2

### Patch Changes

- 239a2f1: - Fix table editor commands not updating the visual row layout when cells are added, removed, or merged. The `TableRow` NodeView now refreshes its grid layout from the current row node on every update (previously it kept reading the stale node captured at creation), and merged cells now emit `grid-column: span N` so they occupy the correct number of grid tracks under the Pages grid-based row layout.
  - Column drags now update row widths live during the drag, instead of snapping to the new width on release. A new `PagesTableView` (also exported, for advanced overrides) mirrors the column-resize plugin's mid-drag `<col>` width updates onto each row's grid-template-columns.
  - Adding or deleting rows and columns on a resized table now preserves the column widths and keeps `<colgroup>` in sync with the row cell count (previously a new row reverted to equal-width tracks, and adding a column left an extra cell wrapping into a second grid line).

## 0.2.1

### Patch Changes

- Updated dependencies [c189c62]
  - @tiptap-pro/extension-convert-kit@0.1.1

## 0.2.0

### Minor Changes

- 830279c: **PagesTableKit — table row grid and height refinements:**

  - TableRow grid columns now use `minmax(0, Nfr)` when every cell has a `colwidth` — this preserves relative column proportions while guaranteeing the row fits the page content area. Fixes DOCX imports where the author drew tables wider than the printable area and the column-width sum overflowed the page.
  - Mixed rows (some cells carry `colwidth`, others do not) fall back to fixed `px` for sized cells and `1fr` for unsized cells.
  - TableRow height now branches on the `heightRule` attribute — `exact` emits `height` + the `--tr-height` custom property (hard clipping preserved), `atLeast` and unset values emit `min-height` so narrower columns can push the row taller instead of clipping content. Mirrors the ConvertKit `renderHTML` behaviour inside the NodeView.

  **Pages — table row overflow containment:**

  - The Pages stylesheet now applies `max-width: 100%`, `min-width: 0`, and `overflow-x: hidden` to `<tr>` elements, plus `min-width: 0` on cells. Contains DOCX-imported tables whose declared widths exceed the page content area so they no longer spill past the page edge.

### Patch Changes

- Updated dependencies [830279c]
  - @tiptap-pro/extension-convert-kit@0.1.0

## 0.1.0

### Minor Changes

- 4f38179: Release of PageKit and TableKit as a separate extensions to cleanup Pages extension
