# Pages TableKit Extension for Tiptap

The **Pages TableKit** extension provides a Pages-aware TableKit configuration for Tiptap. It bundles `@tiptap-pro/extension-table` with settings tuned for paginated layouts, so tables integrate seamlessly with the `@tiptap-pro/extension-pages` extension without additional setup.

---

## License

This extension is proprietary and closed source. All rights reserved. Redistribution or use of the code is not permitted without explicit permission from the authors.
