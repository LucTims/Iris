# PageBreak Extension for Tiptap

The **PageBreak** extension brings advanced page breaking behavior to import and export of documents as proper page break behavior when combined with the pages extension.

---

## License

This extension is proprietary and closed source. All rights reserved. Redistribution or use of the code is not permitted without explicit permission from the authors.
