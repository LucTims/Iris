# @tiptap-pro/extension-pagebreak

## 0.3.4

### Patch Changes

- 3d2b903: Add disclaimer banner to build

## 0.3.3

### Patch Changes

- 154e167: Make `insertPageBreak` place the caret consistently, regardless of `selectable`.

  Previously the command relied on where the selection landed after inserting the node, which differs depending on the page break's `selectable` value: a selectable node leaves the selection on the break, a non-selectable one drops it back into the previous block. With `selectable: false` this left the caret in the wrong place and inserted the new paragraph before the break.

  The break is still inserted with Tiptap's `insertContent`, so it behaves like a normal insert — a selected text range is replaced, a caret inside text splits the block, and the break is placed correctly inside lists and blockquotes. After that, and the same way for any `selectable` value:

  - One empty paragraph (an empty line) is kept right before the break. If there is already an empty paragraph there, it is reused, so two empty lines never appear.
  - The caret is put right after the break, at the start of the next block. A paragraph is added only when the break would otherwise be the last node.

## 0.3.2

### Patch Changes

- 268e706: Fix page breaks under-filling the remaining page space when the editor is zoomed.

## 0.3.1

### Patch Changes

- 0608c46: Minor bugfixes & improvements

## 0.3.0

### Minor Changes

- 4f38179: Add Pages-aware PageBreak behavior and integrate PageBreak into PageKit

  **`@tiptap-pro/extension-pagebreak`**

  - Add Pages-aware node view that fills remaining page space to push content to the next page, mirroring MS Word's page break behavior
  - Register measurement callbacks with the Pages extension's layout refresh cycle for synchronized height updates
  - Implement multi-pass layout stabilization so consecutive page breaks converge correctly
  - Add `insertPageBreak` command with `Mod-Enter` keyboard shortcut
  - Support standard mode (visual dashed rule with label) and Pages mode (invisible space filler)
  - Include drag-and-drop support and DOCX import compatibility

  **`@tiptap-pro/extension-pages`**

  - Add `onAfterPageLayoutCallbacks` storage map for cooperating extensions to hook into the page layout refresh cycle
  - Extend `refreshPage` with multi-pass stabilization that re-runs callbacks until layout converges or the max pass limit is reached
  - Add `getDistanceToNextPagebreak` and `getDistanceToPrevPagebreak` storage APIs for querying pixel distances to page boundaries
  - Schedule post-render recalculations via `requestAnimationFrame` when document changes affect page count
  - Add BFC loop detector reset on legitimate page-count recalculations to prevent false-positive oscillation detection
  - Include `@tiptap-pro/extension-pagebreak` as a peer dependency
  - Bundle PageBreak into PageKit by default (disable with `pagebreak: false`)
  - **BREAKING:** Rename `pageBreakBackground` option to `pageGapBackground`, `setPageBreakBackground` command to `setPageGapBackground`, to avoid confusion with the new PageBreak extension
  - **BREAKING:** Pages extension no longer exports `PageKit` or `TableKit`; they have been moved to separate `@tiptap-pro/extension-pages-pagekit` and `@tiptap-pro/extension-pages-tablekit` extensions.

## 0.2.1

### Patch Changes

- d764c50: Remove the private property from package.json so it's publishable

## 0.2.0

### Minor Changes

- 3b574ff: Add PageBreak extension with visual page break node, keyboard shortcut, and drag-and-drop support
