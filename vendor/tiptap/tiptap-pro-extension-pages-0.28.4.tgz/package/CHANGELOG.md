# @tiptap-pro/extension-pages

## 0.28.4

### Patch Changes

- 7675752: Destroying the editor while a pagination refresh is pending no longer throws, for example when a React component unmounts right after an edit. Before this fix, teardown could fail with "[tiptap error]: The editor view is not available" and skip the remaining cleanup, leaving the Pages stylesheet installed. Calling `destroy()` after `unmount()` is now safe too.
- 7675752: Pagination no longer creates pages without bound when content cannot fit on a page, for example a table row taller than one page. Before this fix the page count could grow by hundreds of pages within seconds and freeze the tab. The page count now stops at the last stable value and a single console warning explains which content caused it. Editing the document resumes normal pagination, and large documents still paginate fully in a few quick steps.

## 0.28.3

### Patch Changes

- 09c7218: Header/footer content now renders identically while editing and on the page.

  Top-level block images in the header/footer static preview render at their natural size instead of being stretched to the full content width by the flex column layout, matching how the overlay editor renders the same content. Intentional centering via auto horizontal margins keeps working. Note that CSS scoped to your editor wrapper only reaches the in-page preview, not the editing overlay mounted on `document.body` — style header/footer images via image attributes or global CSS when both contexts must match.

  Tables now lay out in columns inside the header/footer editing overlay (and the measurement and offscreen sub-editors) instead of collapsing into a narrow stacked box. TableKit owns its grid table layout CSS — `display: contents` unwrapping plus per-row grid tracks — scoped to a `tiptap-pages-tablekit` marker class it adds to every editor that loads it, so the rules apply wherever the kit is used rather than only inside the main Pages editor's uniquely-scoped stylesheet. The injected stylesheet is also reference counted, so destroying one of several editors sharing it (for example a pooled header sub-editor on overlay reconfigure) no longer strips table styling from the editors still alive.

  ConvertKit newly exports the `injectSharedStyle` utility (and its `InjectSharedStyleOptions` type) so companion packages can reference count shared stylesheets across several editors instead of duplicating the lifecycle logic. Existing ConvertKit behavior is unchanged.

- Updated dependencies [e83429c]
- Updated dependencies [09c7218]
  - @tiptap-pro/extension-convert-kit@0.9.0

## 0.28.2

### Patch Changes

- Updated dependencies [2dc0088]
  - @tiptap-pro/extension-convert-kit@0.8.0

## 0.28.1

### Patch Changes

- Updated dependencies [07b5835]
- Updated dependencies [9648903]
  - @tiptap-pro/extension-convert-kit@0.7.0

## 0.28.0

### Minor Changes

- 3a8e918: Node/page attribution now measures each block's content position instead of its box boundary, fixing the first node of every page being filed one page too early (affects `getNodesOnPage`; raw-position semantics of `getPageForPosition` are unchanged). New storage API `getAllNodesWithPages()` returns every block with its page in one cached traversal, and the `PageNodeInfo` type is now exported.

### Patch Changes

- 3d2b903: Add disclaimer banner to build
- Updated dependencies [8d98325]
- Updated dependencies [f75f1fa]
- Updated dependencies [3d2b903]
- Updated dependencies [dad80a9]
- Updated dependencies [8e10677]
- Updated dependencies [e8fc491]
- Updated dependencies [bb0c18e]
  - @tiptap-pro/extension-convert-kit@0.6.0

## 0.27.2

### Patch Changes

- 341b723: Keep the header and footer edit overlays aligned with their page chrome when the surrounding layout shifts without resizing the window

## 0.27.1

### Patch Changes

- @tiptap-pro/extension-convert-kit@0.5.2

## 0.27.0

### Minor Changes

- db86a47: pages: add Word-style endnotes — references collect at the end of the document with lowercase Roman numerals, with a fully editable overlay. DOCX import injects endnotes automatically and DOCX export ships them as real Word endnotes.
- db86a47: pages: add a `toolbarGradient` option to toggle the white fade gradient on the header, footer, footnotes and endnotes edit-overlay toolbars. Defaults to `true`; set `false` for a flat, gradient-free toolbar.

## 0.26.2

### Patch Changes

- @tiptap-pro/extension-convert-kit@0.5.1

## 0.26.1

### Patch Changes

- 969d6fe: Header/footer overlay editing fixes:

  - `setHeaderTopMargin` / `setFooterBottomMargin` (and their resets) now refresh open header/footer overlay editors via the same close-and-reopen used by `setDifferentFirstPage` / `setDifferentOddEven`, so the overlay height context follows the new margins instead of staying stale until the overlay is closed.
  - The header/footer decoration being edited is marked with `data-editing="true"` from the moment its overlay editor opens, and stays marked across decoration rebuilds, so integrators can do whatever they need to.

- Updated dependencies [f0bc8a3]
  - @tiptap-pro/extension-convert-kit@0.5.0

## 0.26.0

### Minor Changes

- cba6675: Add Word-like footnotes: per-page footnote areas above the footer with automatic numbering, reflow with their references, a double-click overlay editor (collaboration-ready), and DOCX import/export round-trip support.

## 0.25.1

### Patch Changes

- Updated dependencies [47dfd9b]
  - @tiptap-pro/extension-convert-kit@0.4.0

## 0.25.0

### Minor Changes

- 481915d: Add Y.js collaboration support for header and footer sub-editors.

  Header and footer sub-editors now participate in real-time collaboration when `@tiptap/extension-collaboration` is wired on the parent editor. Every subtype (default, first page, odd, even — for both headers and footers) collaborates independently. To opt in, pass `headerFooterExtensions` as a callback (the option now accepts `Extensions | (ctx) => Extensions`) and attach a `Collaboration` extension per sub-editor using the Y field handed in via the callback context.

  - The `differentFirstPage` and `differentOddEven` toggles (and their footer counterparts) sync across clients.
  - Remote edits propagate into the page-level header/footer preview on every client even when no overlay is open.
  - Page layout adjusts on remote content growth so the body never overlaps a header that just grew.
  - Optional awareness via `@tiptap/extension-collaboration-cursor` — the callback context exposes provider and user when the parent editor has it installed.

  When wiring collaboration, omit the `header` / `footer` defaults from `Pages.configure()` — Y owns the content in that mode, and a configured default can re-appear after another client has cleared the content. See "Adding collaboration to Pages" in the docs for the full walkthrough.

### Patch Changes

- Updated dependencies [6dd4766]
  - @tiptap-pro/extension-convert-kit@0.3.0

## 0.24.0

### Minor Changes

- d938a80: Add `editableHeader` and `editableFooter` options (default `true`) and matching `setHeaderEditable` / `setFooterEditable` commands. When set to `false`, double-clicking the header/footer no longer opens the inline editor overlay, `openHeaderEditor` / `openFooterEditor` become no-ops, the hover cursor is dropped, and any open overlay is closed.

## 0.23.0

### Minor Changes

- dfd6940: Configurable header/footer placeholders with end-to-end DOCX round-trip support.

  - **Pages**: new `placeholders` option to rename the built-in `{page}` / `{total}` tokens or disable substitution. Defaults preserve existing behavior.
  - **ExportDocx**: header/footer text now translates registered tokens into live Word `PAGE` / `NUMPAGES` fields instead of literal text. When the Pages extension is installed, the export auto-picks up its `placeholders` config so the editor preview and the exported `.docx` stay aligned. Body content is never substituted.
  - **ImportDocx**: the importer now forwards `Pages.options.placeholders` to the convert service so Word `PAGE` / `NUMPAGES` fields come back as text tokens that match your active Pages registry — `{page}` / `{total}` by default, or your rename. The editor preview substitutes the imported tokens natively, with no `.replace()` step and no `placeholders: { total: 'numpages' }` workaround. Pass `placeholders: false` on the command to opt out, or `placeholders: { page, total }` to override the editor's registry per-call.

  The convert service exposes the same `placeholders` field on `/import/docx` and `/export/docx` for direct REST API callers who want the same control without an editor.

- eadb4c6: Switch the default `headerFooterExtensions` for the inner header/footer editors from `StarterKit` to `ConvertKit`. Users not passing a custom `headerFooterExtensions` will now get the richer DOCX-aware default (tables, page break, custom paragraph attributes, CSS resets). To keep the previous behaviour, pass `headerFooterExtensions: [StarterKit]` explicitly when calling `Pages.configure({...})`.

### Patch Changes

- 99d887c: Pages' TableKit now correctly handles tables with custom widths set by table cell attributes
- cf3612d: Add `overflow-x: clip` for table rows, with `overflow-x: hidden` as a fallback, to remove a vertical scrollbar that appeared in header/footer rows on first render.
- 19461cd: Fix the first paint of the document so it matches the layout you get after opening and closing the header/footer editor. The initial header/footer measurement, the re-measurement after `setHeaderTopMargin` / `setFooterBottomMargin`, and any later overlay edits now all re-run the layout configuration. The `--page-max-height` CSS variable (used by tables) stays in sync with the measured heights instead of going stale until the next user action. Also batch the measurement DOM reads to avoid one forced reflow per header/footer, and harden the hidden overlay measurement so a throw inside `setContent` cannot break the singleton overlay.
- Updated dependencies [eadb4c6]
  - @tiptap-pro/extension-convert-kit@0.2.0

## 0.22.1

### Patch Changes

- d43e16d: Match Microsoft Word for `differentFirstPage` and `differentOddEven`:

  - Empty type-specific header/footer slots (first / odd / even) now render empty in the editor instead of silently falling back to the default.
  - `setDifferentOddEven(true)` copies the default content into the odd slot so pages 1, 3, 5... keep showing the existing header/footer (Word continuity). Even pages start empty. `setDifferentFirstPage` does not copy (Word: first slot is a separate blank slot).
  - Toggling either `different*` flag while a header/footer overlay is open now refreshes the overlay so it shows the new variant right away.
  - `setHeader` / `setFooter` and the six typed setters (`setHeader{FirstPage,Odd,Even}` / `setFooter{FirstPage,Odd,Even}`) no longer corrupt storage to `<p></p>` when called while an overlay is open.

## 0.22.0

### Minor Changes

- e9cd180: Add `resetHeaderTopMargin` and `resetFooterBottomMargin` commands to clear the stored margin override and fall back to the active format's default. `setHeaderTopMargin` and `setFooterBottomMargin` now reject `NaN` inputs alongside negative values.

### Patch Changes

- c1e3695: Fix issues with pagination, header/footer sizing, and scrolling when the editor uses CSS `zoom` on mobile. The code now gets the correct scale directly from the element using `getBoundingClientRect`, instead of relying on `storage.zoom`, so page counts stay accurate even when the screen changes.

  It also recalculates the page count right away on first load, so long documents show the correct number without needing any interaction. The pagination wrapper’s `min-height` is rounded to whole pixels to prevent tiny layout changes from triggering unnecessary updates. Lastly, it uses the browser’s built-in `scrollIntoView` while zoomed, so typing no longer causes the view to jump across pages.

## 0.21.1

### Patch Changes

- a18577d: Fix header and footer editor overlays overflowing the page width when zoom is not 100%. Removed the `width: ${100/zoom}%` compensation on `.tiptap-header-editor-container` / `.tiptap-footer-editor-container`. The `zoom` property already scales the inner layout coordinate space by `1/zoom`, so `width: 100%` (from the stylesheet) resolves correctly

## 0.21.0

### Minor Changes

- 53979aa: Expose header and footer inner editor event subscriptions through Pages storage and keep active header/footer state in sync on focus.

  **New storage APIs:**

  - `editor.storage.pages.headerEditorOn` / `editor.storage.pages.headerEditorOff` for subscribing to and unsubscribing from header inner editor events.
  - `editor.storage.pages.footerEditorOn` / `editor.storage.pages.footerEditorOff` for subscribing to and unsubscribing from footer inner editor events.

  **Header/footer focus handling:**

  - Header and footer focus now update `activeEditor`, `activeEditorType`, and `activePageNumber` immediately, so toolbars can react when an inner editor receives focus without waiting for a document update.
  - Header and footer overlays now scope their DOM lookups to the editor instance that opened them, preventing multiple mounted Pages editors from targeting the wrong header or footer element.

### Patch Changes

- 221c1fd: Fix the dynamic header and footer margin reset behavior so that setting `headerTopMargin` or `footerBottomMargin` to `0` restores the default positioning used on the initial render. Also fix the header and footer height on the initial render, as their heights are currently incorrect when these margins are set during initialization.
- fcf94d7: Fix header and footer editor overlays to calculate dynamic heights correctly when zoomed.

## 0.20.1

### Patch Changes

- 830279c: **PagesTableKit — table row grid and height refinements:**

  - TableRow grid columns now use `minmax(0, Nfr)` when every cell has a `colwidth` — this preserves relative column proportions while guaranteeing the row fits the page content area. Fixes DOCX imports where the author drew tables wider than the printable area and the column-width sum overflowed the page.
  - Mixed rows (some cells carry `colwidth`, others do not) fall back to fixed `px` for sized cells and `1fr` for unsized cells.
  - TableRow height now branches on the `heightRule` attribute — `exact` emits `height` + the `--tr-height` custom property (hard clipping preserved), `atLeast` and unset values emit `min-height` so narrower columns can push the row taller instead of clipping content. Mirrors the ConvertKit `renderHTML` behaviour inside the NodeView.

  **Pages — table row overflow containment:**

  - The Pages stylesheet now applies `max-width: 100%`, `min-width: 0`, and `overflow-x: hidden` to `<tr>` elements, plus `min-width: 0` on cells. Contains DOCX-imported tables whose declared widths exceed the page content area so they no longer spill past the page edge.

## 0.20.0

### Minor Changes

- e3f8cd4: Add zoom support to the Pages extension for visual scaling of the editor content.

  **New option:**

  - `zoom` — Set an initial zoom level when configuring the extension (e.g. `Pages.configure({ zoom: 0.75 })`). Accepts values from `0.25` (25%) to `4` (400%). Defaults to `1` (100%).

  **New command:**

  - `editor.commands.setZoom(value)` — Dynamically change the zoom level at any time. The value is clamped to the `[0.25, 4]` range.

  **New storage properties:**

  - `editor.storage.pages.zoom` — Read the current zoom level.
  - `editor.storage.pages.getZoom?.()` — Get the current zoom level (function form for symmetry with other storage getters).

  **New callback:**

  - `onZoomChange` — Option callback invoked whenever the zoom level changes, useful for keeping UI controls in sync (e.g. a zoom dropdown or slider).

  **Zoom behavior:**

  - Applies visual scaling to the entire editor including page content, headers, footers, and page breaks.
  - Header and footer editors automatically match the current zoom level, including when zoom changes while an editor is open.
  - Pagination calculations remain accurate at all zoom levels.
  - Does not affect document structure or print output — zoom is purely visual.

## 0.19.1

### Patch Changes

- 990f322: Remove unused `@tiptap-pro/extension-pagebreak` peer dependency

## 0.19.0

### Minor Changes

- 4f38179: Add Pages-aware PageBreak behavior and integrate PageBreak into PageKit

  **`@tiptap-pro/extension-pagebreak`**

  - Add Pages-aware node view that fills remaining page space to push content to the next page, mirroring MS Word's page break behavior
  - Register measurement callbacks with the Pages extension's layout refresh cycle for synchronized height updates
  - Implement multi-pass layout stabilization so consecutive page breaks converge correctly
  - Add `insertPageBreak` command with `Mod-Enter` keyboard shortcut
  - Support standard mode (visual dashed rule with label) and Pages mode (invisible space filler)
  - Include drag-and-drop support and DOCX import compatibility

  **`@tiptap-pro/extension-pages`**

  - Add `onAfterPageLayoutCallbacks` storage map for cooperating extensions to hook into the page layout refresh cycle
  - Extend `refreshPage` with multi-pass stabilization that re-runs callbacks until layout converges or the max pass limit is reached
  - Add `getDistanceToNextPagebreak` and `getDistanceToPrevPagebreak` storage APIs for querying pixel distances to page boundaries
  - Schedule post-render recalculations via `requestAnimationFrame` when document changes affect page count
  - Add BFC loop detector reset on legitimate page-count recalculations to prevent false-positive oscillation detection
  - Include `@tiptap-pro/extension-pagebreak` as a peer dependency
  - Bundle PageBreak into PageKit by default (disable with `pagebreak: false`)
  - **BREAKING:** Rename `pageBreakBackground` option to `pageGapBackground`, `setPageBreakBackground` command to `setPageGapBackground`, to avoid confusion with the new PageBreak extension
  - **BREAKING:** Pages extension no longer exports `PageKit` or `TableKit`; they have been moved to separate `@tiptap-pro/extension-pages-pagekit` and `@tiptap-pro/extension-pages-tablekit` extensions.

### Patch Changes

- Updated dependencies [4f38179]
  - @tiptap-pro/extension-pagebreak@0.3.0

## 0.18.0

### Minor Changes

- fcd13d5: Initial beta point for export and pages packages
