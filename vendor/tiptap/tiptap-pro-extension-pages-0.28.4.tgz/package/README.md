# Pages Extension for Tiptap

The **Pages** extension brings advanced pagination, page formatting, and print-like layout to your Tiptap editor. It supports real-world page sizes, customizable headers and footers, and more—making it ideal for document editing, print previews, and professional publishing workflows.

## License

This extension is proprietary and closed source. All rights reserved. Redistribution or use of the code is not permitted without explicit permission from the authors.
